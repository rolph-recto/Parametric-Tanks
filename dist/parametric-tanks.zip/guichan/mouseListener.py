#!/usr/bin/env python

from guichan import *

class MouseListener:
    def mouseEntered(self,mouseEvent):
        pass
    
    def mouseExited(self,mouseEvent):
        pass
    
    def mousePressed(self,mouseEvent):
        pass
    
    def mouseReleased(self,mouseEvent):
        pass
    
    def mouseClicked(self,mouseEvent):
        pass
    
    def mouseWheelMovedUp(self,mouseEvent):
        pass
    
    def mouseWheelMovedDown(self,mouseEvent):
        pass
    
    def mouseMoved(self,mouseEvent):
        pass
    
    def mouseDragged(self,mouseEvent):
        pass