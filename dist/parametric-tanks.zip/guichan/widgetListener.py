#!/usr/bin/env python

from guichan import *
from event import Event

class WidgetListener:
    def widgetResized(self,event):
        pass
    def widgetMoved(self,event):
        pass
    def widgetHidden(self,event):
        pass
    def widgetShown(self,event):
        pass