#!/usr/bin/env python

from guichan import *
from keyInput import KeyInput
from mouseInput import MouseInput

class Input:
    def isKeyQueueEmpty(self):
        pass
    
    def dequeueKeyInput(self):
        pass
    
    def isMouseQueueEmpty(self):
        pass
    
    def dequeueMouseInput(self):
        pass
    
    def pollInput(self):
        pass