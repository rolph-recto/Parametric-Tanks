#!/usr/bin/env python

from guichan import *

class KeyListener:
    def keyPressed(self,keyEvent):
        pass
    
    def keyReleased(self,keyEvent):
        pass