#!/usr/bin/env python

from guichan import *
from actionEvent import ActionEvent

class ActionListener:
    def Action(self,action):
        pass