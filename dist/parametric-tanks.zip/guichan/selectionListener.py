#!/usr/bin/env python

from guichan import *
from selectionEvent import SelectionEvent

class SelectionListener:
    def valueChanged(self,selectionEvent):
        pass