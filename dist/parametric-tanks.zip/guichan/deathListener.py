#!/usr/bin/env python

from guichan import *
from event import Event

class DeathListener:
    def death(self,event):
        pass