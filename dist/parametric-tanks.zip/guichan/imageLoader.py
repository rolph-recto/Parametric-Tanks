#!/usr/bin/env python

from guichan import *

class ImageLoader:
    def load(file,convertToDisplayFormat=True):
        pass