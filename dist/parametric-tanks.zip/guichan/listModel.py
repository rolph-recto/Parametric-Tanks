#!/usr/bin/env python

from guichan import *

class ListModel:
    def getNumberOfElements(self):
        pass

    def getElementAt(self,i):
        pass