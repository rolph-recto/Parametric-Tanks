#!/usr/bin/env python

from guichan import *
from event import Event

class FocusListener:
    def focusGained(self,event):
        pass
    
    def focusLost(self,event):
        pass