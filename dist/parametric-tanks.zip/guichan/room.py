#!/usr/bin/env python

from message import *

print MSG_DEFAULT_CALLBACK